package com.example.marin.qrticket.activity;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.marin.qrticket.R;
import com.example.marin.qrticket.model.Usuario;
import com.example.marin.qrticket.util.RetrofitUtil;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    private Button btnLogin;
    private Button btnNC;
    private EditText edtLogin;
    private EditText edtSenha;
    private static final int REDIRECT = 200;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if (android.os.Build.VERSION.SDK_INT > 9)
        {
            StrictMode.ThreadPolicy policy = new
                    StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        btnLogin = (Button) findViewById(R.id.btnLogar);
        edtLogin = (EditText) findViewById(R.id.edtLog);
        edtSenha = (EditText) findViewById(R.id.edtSen);
        btnNC = (Button) findViewById(R.id.btnNovaConta);

        btnLogin.setOnClickListener(this);
        btnNC.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnLogar){

            String login = edtLogin.getText().toString();
            String senha = edtSenha.getText().toString();

            Usuario u = new Usuario();
            u.setLogin(login);
            u.setSenha(senha);

            final RetrofitUtil retrofitUtil = RetrofitUtil.retrofit.create(RetrofitUtil.class);
            final Call<Usuario> call = retrofitUtil.logar(u);

            call.enqueue(new Callback<Usuario>() {
                @Override
                public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                    if (response.isSuccessful()){
                        Usuario ui = new Usuario();
                        ui = response.body();
                        Toast.makeText(getBaseContext(), ui.getNome(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<Usuario> call, Throwable t) {
                        t.printStackTrace();
                }
            });
        }else if (view.getId() == R.id.btnNovaConta){
            Intent intent = new Intent(LoginActivity.this, CadastrarUsuario.class);
            startActivityForResult(intent, REDIRECT);
        }
    }
}
